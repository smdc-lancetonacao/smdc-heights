document.addEventListener('DOMContentLoaded', function () {
    const navbar = document.getElementById('navbar');

    if (navbar && navbar.classList.contains('homepage-navbar')) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 10) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }
});