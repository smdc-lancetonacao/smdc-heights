<?php
$map_title = get_field('map_title');
$map_description = get_field('map_description');
$map_count_title = get_field('map_count_title');
$map_count_description = get_field('map_count_description');

$map_image = get_field('map_image');
$map_image_url = is_array($map_image) ? $map_image['url'] : $map_image;

$theme_url = get_template_directory_uri();
?>

<?php if ($map_title || $map_description || $map_count_title || $map_count_description || $map_image): ?>
    <section class="map-section">
        <div class="map-container">

            <!-- Left Column: Text Groups -->
            <div class="map-texts">
                <?php if ($map_title): ?>
                    <h2 class="map-title"><?php echo ($map_title); ?></h2>
                <?php endif; ?>
                <div class="map-texts-group">
                    <div class="map-group-top">
                        <?php if ($map_description): ?>
                            <p class="map-description"><?php echo esc_html($map_description); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="map-group-bottom">
                        <img class="skycrapper-img" src="<?php echo $theme_url; ?>/assets/images/skycrapper-img.png" alt="Skycrapper Image">
                        <div class="map-group-bottom-texts">
                            <?php if ($map_count_title): ?>
                                <h3 class="map-count-title"><?php echo esc_html($map_count_title); ?></h3>
                            <?php endif; ?>

                            <?php if ($map_count_description): ?>
                                <p class="map-count-description"><?php echo esc_html($map_count_description); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Map Image -->
            <div class="map-image-wrapper">
                <?php if ($map_image_url): ?>
                    <img class="map-image" src="<?php echo esc_url($map_image_url); ?>" alt="Map Image">
                <?php endif; ?>
            </div>
            <!-- <div class="map-image-wrapper">
                <div class="interactive-map map-image">
                    <?php //echo file_get_contents(get_template_directory() . '/assets/images/NCR.svg'); ?>
                </div>
            </div> -->
        </div>
    </section>
<?php endif; ?>